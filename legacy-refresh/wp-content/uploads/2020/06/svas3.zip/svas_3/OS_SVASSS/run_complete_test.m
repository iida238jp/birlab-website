% run the tests on different materials
% clear all
close all

% method of sensor creation
% 1 = distance
% 2 = cost
% 3 = random 
method = 2;
noLines = 1;

% test 1

[Deformation_SI,Sensors_SI] = totalClustering('Plus',method);
% [Deformation_HMA,Sensors_HMA] = totalClustering('HMA_S',method);


selected_Def = Deformation_SI;
selected_Sen = Sensors_SI;

   % NOW TAKE ONE SENSOR AND TEST IT ON EVERY OTHER DEFORMATION 
   figure(66)
   sv = 0.5;
   fin_res = zeros(size(selected_Def,2),4,size(selected_Def,2));
    for i = 1 : size(selected_Def,2)
        [res_trueStrain,res_errorStrain] = testSensors(selected_Def,selected_Sen(i));
        res_trueStrain = res_trueStrain*noLines;
        fin_res(:,1,i) = res_trueStrain+res_errorStrain;
        fin_res(:,2,i) = res_errorStrain;
        fin_res(:,3,i) = selected_Sen(i).baseR + res_trueStrain+res_errorStrain;
        fin_res(:,4,i) = ((res_trueStrain+res_errorStrain)/selected_Sen(i).baseR)*100;
        
        
        % bar graph
        subplot(size(selected_Def,2),1,i)
        bar(res_errorStrain+res_trueStrain,'b')
        hold on
        bar(res_errorStrain,'r')
        
        
        x = [1:size(selected_Def,2)];
        y = res_errorStrain+res_trueStrain;
        z = res_trueStrain./(res_errorStrain+res_trueStrain)*100;
        
        % add percentage of true strain value on bars
        for i1 = 1:numel(x)
            text(x(i1),y(i1),strcat('%',num2str(z(i1),'%2.2f')),...
            'horiz','center','vert','bottom')
            
        end
        
        if i ~= size(selected_Def,2)
%             set(gca,'XTick',[1 2 3 4 5 6 7] );
            set(gca,'XTickLabel',[ ] );
        else
            set(gca,'XTick',[1 2 3 4 5 6 7] ); %This are going to be the only values affected.
%             set(gca,'XTickLabel',[0.5 1.0 1.5 2.0 2.5 3.0 3.5] );            
        end
        
        add = gca;
        extra = axes('Position',get(add,'Position'),'Color','none','XTick',[],'YTick',[],'YAxisLocation','right');
        linkaxes([add extra],'xy');
        str = 'S-';
%         ylabel(strcat(str,num2str(sv,'%1.1f')));
%         sv = sv +0.5;
        ylabel(strcat(str,num2str(i,'%1.1f')));

        axis([0.5 size(selected_Def,2)+0.5 0 40] )
        

    end
%     ylabel('Resistance (\Omega)');
    xlabel('Torque (Nmm)');
    
    figure(67)
       
    plot(fin_res(:,1,1),'k', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,1,2),'r', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,1,3),'b', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,1,4),'g', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,1,5),'m', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,1,6),'c', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,1,7),'y', 'LineWidth',1.5);   
    
    legend('1.0N','2.0N','3.0N','4.0N','5.0N','6.0N','7.0N','Location','NorthWest');

    title('SI Twisting - Cost Function','FontWeight','bold');
%     set(gca,'XTick',[1 2 3 4 5 6 7] ); %This are going to be the only values affected.
%     set(gca,'XTickLabel',[0.5 1.0 1.5 2.0 2.5 3.0 3.5] ); %This is what it's going to appear in those places.
    ylabel('\Delta Resistance (\Omega)');
    xlabel('Torque (Nmm)');
    
    
        figure(68)
       
    plot(fin_res(:,3,1),'k', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,3,2),'r', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,3,3),'b', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,3,4),'g', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,3,5),'m', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,3,6),'c', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,3,7),'y', 'LineWidth',1.5);   
    
    legend('1.0N','2.0N','3.0N','4.0N','5.0N','6.0N','7.0N','Location','NorthWest');

    title('SI Twisting - Cost Function','FontWeight','bold');
%     set(gca,'XTick',[1 2 3 4 5 6 7] ); %This are going to be the only values affected.
%     set(gca,'XTickLabel',[0.5 1.0 1.5 2.0 2.5 3.0 3.5] ); %This is what it's going to appear in those places.
    ylabel('\Sigma Resistance (\Omega)');
    xlabel('Torque (Nmm)');
    
            figure(69)
       
    plot(fin_res(:,4,1),'k', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,4,2),'r', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,4,3),'b', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,4,4),'g', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,4,5),'m', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,4,6),'c', 'LineWidth',1.5);
    hold on
    plot(fin_res(:,4,7),'y', 'LineWidth',1.5);   
    
    legend('1.0N','2.0N','3.0N','4.0N','5.0N','6.0N','7.0N','Location','NorthWest');

    title('Twisting - min(Cost) Function','FontWeight','bold');
%     set(gca,'XTick',[1 2 3 4 5 6 7] ); %This are going to be the only values affected.
%     set(gca,'XTickLabel',[0.5 1.0 1.5 2.0 2.5 3.0 3.5] ); %This is what it's going to appear in those places.
    ylabel('% Resistance Ratio (\Delta R / \Sigma R )');
    xlabel('Torque (Nmm)');
    
