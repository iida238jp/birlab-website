SVAS3: Strain vector aided sensorization of soft structures
Authors: Utku Culha, Surya G. Nurzaman, Frank Clemens and Fumiya Iida
Bio-inspired Robotics Lab, ETH Zurich, Switzerland

PLEASE READ THIS FILE BEFORE RUNNING THE SIMULATION

This folder consists all the necessary files to run the sensorization simulation of soft structures. Please note that VoxCAD[1] is used to
model, simulate and generate soft sturcture deformations and strain vectors from these deformations. A sample deformation can be found under 
"test_sets" where all necessary strain vectors are generated. Here is the list of files that are required:

1. run_complete_test.m
2. totalClustering.m
3. neighboorPath.m
4. placeSensors.m
5. createSensor.m
6. testSensors.m
7. test_sets folder
7.1 "Plus" folder 
8. README.txt

This simulation uses the extracted strain vectors as a guide to design and place strain gauge sensors on the soft structures. In order to run the
simulation (1) should be run on Matlab. This file requires path to the folder of sample deformations. The path to (7.1) is set by default. (2) reads all 
the strain vectors files that belongs to 7 stages of a complete deformation sequence. It clusters these strain vectors w.r.t. magnitude and direction. (3) 
takes these clusters and forms physically unique neighboorhoods. (4) places a straight line shape sensor fragment in all of these neighborhoods. (5) 
connects these line fragments w.r.t. chosen connection method, whose details can be found in the file. After chosen line fragments are connected to each
other, a single sensor shape is formed. A single sensor is generated for each of 7 deformation stages. These sensors are tested with (6) to estimate
sensory outputs. Fiber shaped strain gauge sensors that are fabricated with a conductive thermoplastic elastomer [2] are modeled in this simulation. 
These sensors are responsive to strain and generate change of resistantance as a sensor output.

The simulation generates several figures:
Figure 1-7: The strain vectors and physical neighborhoods in each deformation, along with the final sensor design.
Figure 66: The estimated sensory signal output noise ratio of every 7 sensor for every 7 deformation.
Figure 67: The estimated change of resistance of each sensor in every deformation.
Figure 68: The estimated sensor output of each sensor in every deformation.
Figure 69: The estimated ratio of change of resistance to sensor output of each sensor in every deformation.

References:

[1] Culha U.;Nurzaman S.G.;Clemens F.; Iida F. SVAS3: Stain Vector Aided Sensorization of Soft Structures. Sensors 2014, 14, 12748-12770.
[2] VoxCAD, http://www.voxcad.com/
[3] Mattmann, C; Clemens, F.;Troster, G. Sensor for measuring strain in textile. Sensors 2008, 8, 3719-3732.

