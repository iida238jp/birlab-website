function [output,senReg,senAng,senMag] = placeSensors(strVecs,regions,centroid,mergeID, clusAngs,sThres, lConst,voxelInfo)

% find the amount of unique regions
noRegs = unique(regions);
% output = end point of sensors
output = zeros(size(noRegs,1),4);
% senReg = regions which the sensor belongs to
senReg = zeros(size(noRegs,1),1);
% senAng = angle of the sensor
senAng = zeros(size(noRegs,1),1);
% senMag = sensor strain magnitude
senMag = zeros(size(noRegs,1),1);

h =0;

surfaceSize = voxelInfo(1) / voxelInfo(4); 
finalIndex = (voxelInfo(1) - surfaceSize) - 1;

for i=1:length(noRegs)
    
%     if i > length(noRegs)
%         break;
%     end
    
    if noRegs(i) ~= 0
        
        % strain vectors inside this neighborhood
        vecs = squeeze(strVecs(1,regions == noRegs(i),:));
        
        % find the average magnitude of strain in that region
        strAvMag = mean( sqrt(vecs(:,2).^2 + vecs(:,3).^2 ) );
        strTotMag = sum( sqrt(vecs(:,2).^2 + vecs(:,3).^2 ) );
        
        % if average magnitude is smaller than threshold, then skip this
        % region
        
        if strAvMag >= sThres 
                                   
                output(i,:) = [0 0 0 0];
                senReg(i) = 0;
                senAng(i) = 0;
                senMag(i) = 0;
                
                % find the center point
                cPoint = centroid(i,:);
            
%                 % find average direction angle          
%                 angAv = clusAngs(unique(mergeID(vecs(:,1) - finalIndex)));

                % find the average angle in the current region. NOT ALL
                % CLUSTER               
                angAv =  mod(mean(atan2(vecs(:,3),vecs(:,2))),2*pi);
                
                % initiate max line fitting starting from maxScale to lConst
                maxScale = 0.1;
                % create 1000 points in between smaller case to max case
                upTop = 1000;
                testScales = linspace(maxScale,lConst,upTop);
                
                % find the greatest x distance in the region
                maxD = max(vecs(:,5)) - min(vecs(:,5));
                
                if strAvMag > maxD
                    testScales = testScales / (strAvMag/maxD);
                end
                
                
                for j=1:upTop
                    
%                     if h~=0
%                         delete h;
%                     end
                    
                    lScale = testScales(j);
                    % find the total length of the sensor
                    sLength = lScale * (strAvMag);

                    % find end points of the sensor            
                    p1 = [cPoint(1) + (sLength/2)*cos(angAv), cPoint(2) + (sLength/2)*sin(angAv)];
                    p2 = [cPoint(1) - (sLength/2)*cos(angAv), cPoint(2) - (sLength/2)*sin(angAv)];

                    % Expand the region to contain real boundaries. without
                    % this, we can only check the boundaries of voxel centers ( it
                    % will only add up sqrt(voxel_edge/2), which is nearly 0.8 mms,
                    % THEREFORE I SKIP IT FOR NOW !

                    % check if sensor end points are within the region
                    % point 1
                    pts = repmat(p1,size(vecs,1),1);
                    dists = sqrt( (vecs(:,5)-pts(:,1)).^2 + (vecs(:,6)-pts(:,2)).^2 );
                    % check if any of points in region is close to sensor end
                    % points lower than average strain value           
                    res1 = sum(dists < (0.0015/2)*sqrt(2));
                    
                    % check for p1 if it's still in same region, for concave region maps
                    cv_pts = repmat(p1,size(strVecs,2),1);
                    cv_dists = sqrt( (strVecs(1,:,5)'-cv_pts(:,1)).^2 + (strVecs(1,:,6)'-cv_pts(:,2)).^2 );
                    [p1Max,p1Ind] = max(cv_dists < (0.0015/2)*sqrt(2));
                    
                    if p1Max > 0
                       % check region, it another region, break
                       if regions(p1Ind) ~= noRegs(i)
                           break;
                       end
                    end
                                       
                    % point 2
                    pts = repmat(p2,size(vecs,1),1);
                    dists = sqrt( (vecs(:,5)-pts(:,1)).^2 + (vecs(:,6)-pts(:,2)).^2 );
                    % check if any of points in region is close to sensor end
                    % points lower than average strain value           
                    res2 = sum(dists < (0.0015/2)*sqrt(2));
                    
                    % check for p1 if it's still in same region, for concave region maps
                    cv_pts = repmat(p2,size(strVecs,2),1);
                    cv_dists = sqrt( (strVecs(1,:,5)'-cv_pts(:,1)).^2 + (strVecs(1,:,6)'-cv_pts(:,2)).^2 );                
                    [p2Max,p2Ind] = max(cv_dists < (0.0015/2)*sqrt(2));
                    
                    if p2Max > 0
                       % check region, it another region, break
                       if regions(p2Ind) ~= noRegs(i)
                           break;
                       end
                    end
                    
                    % CHECK HERE IF P1 AND P2 ARE STILL IN SAME REGION
                    % ELSE BREAK
                                        
                    if res1 >= 1 && res2 >=1          
                        
%                         magConst = 1;
%                         % update sensor magnitude w.r.t. direction
%                         if angAv >= 0 && angAv <= pi/2
%                             magConst = 1;
% %                             strAvMag = strAvMag*1;
%                         end
% 
%                         % region 2 of unit circle: y positive
%                         if angAv >= pi/2 && angAv <= pi
%                             magConst = sin(angAv);
% %                             strAvMag = abs(strAvMag*sin(angAv));
%                         end
% 
%                         % region 3 of unit circle: all negative
%                         if angAv >= pi && angAv <= (3*pi)/2
%                             magConst = 0; 
% %                             strAvMag = strAvMag*0;
%                         end
% 
%                         % region 4 of unit circle: x positive
%                         if angAv >= (3*pi)/2 && angAv <= 2*pi
%                             magConst = cos(angAv);
% %                             strAvMag = abs(strAvMag*cos(angAv));
%                         end


                        % region strain angle
                        clsAng = angAv;
                        % sensor line angle
                        connAng = mod(atan2(p1(2)-p2(2),p1(1)-p2(1)),2*pi);
                        % correct if line goes through reg. II
                        if connAng >= pi/2 && connAng <= pi
                            connAng = connAng + pi;
                        end
                        % correct of line goes through reg. III
                        if connAng >= pi && connAng <= 3*pi/2
                            connAng = connAng - pi;
                        end
                        % strain vector magnitude
                        strV = strAvMag;
    
                        clsProj = 1;
                        if clsAng >= connAng
                            clsProj = strV*cos(clsAng - connAng);
                            if connAng >= 0 && connAng <= pi/2 % I
                                if clsProj >= 0
                                    clsProj = clsProj; % projection is in reg. I
                                else
                                    clsProj = 0; % projection is in reg. III
                                end
                            end

                            if connAng >= 3*pi/2 && connAng <= 2*pi % IV
                                % projection will always be + and in IV
                                clsProj = clsProj * cos(2*pi - connAng);
                            end                    
                        else
                            clsProj = strV*cos(connAng - clsAng);

                            if connAng >= 0 && connAng <= pi/2 % I
                                % projection will always be + and in I
                                clsProj =  clsProj;
                            end

                            if connAng >= 3*pi/2 && connAng <= 2*pi % IV
                                if clsProj >= 0 % projection is in IV
                                    clsProj = clsProj * cos(2*pi - connAng); 
                                else
                                    % projection is in reg II
                                    clsProj = abs(clsProj * cos(connAng - 3*pi/2));
                                end

                            end
                        end

%                         clsProj = clsProj * 1000 * G;
                        
                        % append point
                        output(i,:) = [p1 p2];
                        % append region id
%                         senReg(i) = unique(mergeID(vecs(:,1) - finalIndex));
                        senReg(i) = noRegs(i);
                        % append sensor angle
                        senAng(i) = connAng;
                        % append sensor total strain
                        sensorL = sqrt((p1(1)-p2(1))^2 + (p1(2)-p2(2))^2);
                        % strain magnitude in mm
%                         senMag(i) = abs(sensorL*strAvMag*magConst);
                        senMag(i) = abs((sensorL/0.0015)*clsProj*0.0015);
                                              
                        
                        % debug sensor                                
%                         h = plot([p1(1) p2(1)], [p1(2) p2(2)], 'k', 'LineWidth',1.5 );
                    end              
                end
        else
            output(i,:) = [0 0 0 0];
            senReg(i) = 0;
            senAng(i) = 0;
            senMag(i) = 0;
        end
        
    else
        output(i,:) = [0 0 0 0];
        senReg(i) = 0;
        senAng(i) = 0;
        senMag(i) = 0;
    end
   
end

end