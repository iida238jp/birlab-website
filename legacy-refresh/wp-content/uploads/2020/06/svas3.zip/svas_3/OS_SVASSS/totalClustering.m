function [Deformation, Sensors] = totalClustering(path,method)

% reads the strain vector files from the folder
% voxel size = 1.5 mm
% total sheet size = 90mm x 45 mm x 4.5 mm
% every surface has 1800 voxels

% sensor connection method
pathname = strcat('test_sets\',path);
pathname = strcat(pathname,'\');

% read the info file to detect the sizes

infoPath = strcat(pathname,'\Info\voxelInfo.txt');
voxelInfoFile = load(infoPath);

% now define base sizes, indexes
totalVoxels = voxelInfoFile(1);
xSize = voxelInfoFile(2);
ySize = voxelInfoFile(3);
zSize = voxelInfoFile(4);
surfaceSize = totalVoxels / zSize;

% voxelInfo = [totalSize, xSize, ySize, zSize]
voxelInfo = [totalVoxels, xSize, ySize, zSize];



Files=dir(strcat(pathname,'*.txt'));

% cluster working set
raw = [];
mags = [];
% complete strain vector set
strVecs = zeros(10,surfaceSize,7);
% complete neighboorhood set
neighboor = zeros(10,surfaceSize,1);
% final sensor points
Sensors = struct;
% rough set
comp = [];
% every deformation body
Deformation = struct;

% cluster number
noCluster = 8;

for i=1:length(Files)
    % read the file name
    FileNames=Files(i).name;
    filePath = strcat(pathname,FileNames);
    data = load(filePath);

    % fill the complete vector space
    strVecs(i,:,:) = data((totalVoxels-surfaceSize+1):totalVoxels,:);
    comp = [comp;data((totalVoxels-surfaceSize+1):totalVoxels,:)];
    
    % get the strain vector (x,y) of the third
    % (top) layer of the body
    rawD = data((totalVoxels-surfaceSize+1):totalVoxels,[2:3]);
    
%     mags = [mags;rawD];
    
    rawD = atan2(rawD(:,2),rawD(:,1));
    
    % generate a big vector space
    raw = [raw;rawD];
    
   
end

% save Mag_Data mags;
% save Angle_Data raw;


% now cluster this vector space into 8 classes ( hopefully compass
% directions)

opts = statset('Display','final');
% [idx,C] = kmeans(raw,noCluster,'emptyaction','drop','Replicates',100,'Options',opts);

 rand('seed',11);
[idx,C] = kmeans(raw,noCluster,'EmptyAction','singleton','Start','uniform');


% find the cluster statistics

% cluster of strain directions only
% clu1 = rad2deg(atan2(raw(idx==1,2),raw(idx==1,1)));
% clu2 = rad2deg(atan2(raw(idx==2,2),raw(idx==2,1)));
% clu3 = rad2deg(atan2(raw(idx==3,2),raw(idx==3,1)));
% clu4 = rad2deg(atan2(raw(idx==4,2),raw(idx==4,1)));
% clu5 = rad2deg(atan2(raw(idx==5,2),raw(idx==5,1)));
% clu6 = rad2deg(atan2(raw(idx==6,2),raw(idx==6,1)));
% clu7 = rad2deg(atan2(raw(idx==7,2),raw(idx==7,1)));
% clu8 = rad2deg(atan2(raw(idx==8,2),raw(idx==8,1)));

clu1 = rad2deg(raw(idx==1));
clu2 = rad2deg(raw(idx==2));
clu3 = rad2deg(raw(idx==3));
clu4 = rad2deg(raw(idx==4));
clu5 = rad2deg(raw(idx==5));
clu6 = rad2deg(raw(idx==6));
clu7 = rad2deg(raw(idx==7));
clu8 = rad2deg(raw(idx==8));


means = [mean(clu1);mean(clu2);mean(clu3);mean(clu4);mean(clu5);mean(clu6);mean(clu7);mean(clu8)];
stds = [std(clu1);std(clu2);std(clu3);std(clu4);std(clu5);std(clu6);std(clu7);std(clu8)];

% figure(11)
% errorbar(means,stds,'r*','LineWidth',1.5);

% now do the class merge

% the resultant indexes found by kmeans
newInd = [1:1:noCluster];
% the visited index vector
visInd = zeros(1,noCluster);
% modded center matrix
modC = mod(C,2*pi);
% merging threshold
mThres = deg2rad(15);
% vector strength threshold
sThres = 5e-6;
% sensor length threshold
lThres = 0.0005;
% sensor length multipler
lConst = 100;



% for i=1:noCluster
%     
%     % for every cluster center, check if other classes have close centers.
%     % If so, merge these classes. The phase is 2*pi with a threshold value
%     % to be admitted to merge
%     for j=1:noCluster     
%         if(j ~= i)           
%             % find cluster difference
%             clDiff = abs(modC(i) - modC(j));
%             % if difference is < threshold, merge the clusters
%             if((clDiff < mThres)&&(visInd(i)~=1) ) || (abs(clDiff - 2*pi) < sThres)
%                 newInd(j) = newInd(i);              
%             end                        
%         end        
%     end
%     
%     visInd(i) = 1;
% end
     
     
     % get all graphs with strain vectors and clusters
     
    for i=1:length(Files)
        % clustered data
        currD = comp(((i-1)*surfaceSize + 1):i*surfaceSize,:);
        currID = idx(((i-1)*surfaceSize + 1):i*surfaceSize,:);
        
        
        figure(i)
         
        subplot(1,2,1)
        % strain vectors
        quiver3(strVecs(i,:,5),strVecs(i,:,6),strVecs(i,:,7),strVecs(i,:,2),strVecs(i,:,3),strVecs(i,:,4));
        view(2);
        axis equal
        axis([min(currD(:,5))-0.008 max(currD(:,5))+0.008 min(currD(:,6))-0.001 max(currD(:,6))+0.001]);
        
        subplot(1,2,2)          
        plot(currD(currID==1,5),currD(currID==1,6),'r.','MarkerSize',12);
        hold on
        plot(currD(currID==2,5),currD(currID==2,6),'ro','MarkerSize',5);
        hold on
        plot(currD(currID==3,5),currD(currID==3,6),'g.','MarkerSize',12);
        hold on
        plot(currD(currID==4,5),currD(currID==4,6),'go','MarkerSize',5);
        hold on
        plot(currD(currID==5,5),currD(currID==5,6),'b.','MarkerSize',12);
        hold on
        plot(currD(currID==6,5),currD(currID==6,6),'bo','MarkerSize',5);
        hold on
        plot(currD(currID==7,5),currD(currID==7,6),'c.','MarkerSize',12);
        hold on
        plot(currD(currID==8,5),currD(currID==8,6),'co','MarkerSize',5);
        axis equal
        axis([min(currD(:,5))-0.008 max(currD(:,5))+0.008 min(currD(:,6))-0.001 max(currD(:,6))+0.001]);
        
        mergeID = currID;
        % update the merged clusters
%         for j=1:noCluster
%             mergeID(mergeID == j) = newInd(j);
%         end
        
%         subplot(1,3,3)
%         plot(currD(mergeID==1,5),currD(mergeID==1,6),'r.','MarkerSize',12);
%         hold on
%         plot(currD(mergeID==2,5),currD(mergeID==2,6),'ro','MarkerSize',5);
%         hold on
%         plot(currD(mergeID==3,5),currD(mergeID==3,6),'g.','MarkerSize',12);
%         hold on
%         plot(currD(mergeID==4,5),currD(mergeID==4,6),'go','MarkerSize',5);
%         hold on
%         plot(currD(mergeID==5,5),currD(mergeID==5,6),'b.','MarkerSize',12);
%         hold on
%         plot(currD(mergeID==6,5),currD(mergeID==6,6),'bo','MarkerSize',5);
%         hold on
%         plot(currD(mergeID==7,5),currD(mergeID==7,6),'c.','MarkerSize',12);
%         hold on
%         plot(currD(mergeID==8,5),currD(mergeID==8,6),'co','MarkerSize',5);
%         hold on
        
        % find the vector magnitudes: if they are weaker than threshold, 
        % then there is no need to attach sensors there
        
        % find magnitude vector
        strVec = sqrt(currD(:,2).^2 + currD(:,3).^2);
        % strength index vector
        strInd = strVec < sThres;
        
        % now delete the weak vectors
        plot(currD(strInd==1,5),currD(strInd==1,6),'ko','MarkerSize',5);
        hold on
        plot(currD(strInd==1,5),currD(strInd==1,6),'k.','MarkerSize',12);
        hold on
        axis equal

        axis([min(currD(:,5))-0.008 max(currD(:,5))+0.008 min(currD(:,6))-0.001 max(currD(:,6))+0.001]);
        
        % now find the region center and draw a line on strain vector
        % direction
        
        orgmergeID = mergeID;
        mergeID(strInd == 1) = 0;
        
        % first find distinct neighboorhoods and their centroids
        [regions,centroids] = neighboorPath(strVecs(i,:,:),mergeID, strInd,3,voxelInfo);       
        neighboor(i,:,:) = regions;
        
        mergeID = orgmergeID;
        
        % plot the centroids
        plot(centroids(:,1), centroids(:,2), 'kX', 'MarkerSize',12);
        hold on
        
%         % draw neighboorhoods
%         subplot(1,3,3)
% 
%         strRegions = strtrim(cellstr(num2str(regions,'%d')));
%         text(currD(:,5),currD(:,6),strRegions);
% 
%         axis([min(currD(:,5))-0.008 max(currD(:,5))+0.008 min(currD(:,6))-0.001 max(currD(:,6))+0.001]);
% %         axis equal
        
        % find sensor placements
        [sensorPts,senRegs,senAng,senMag] = placeSensors(strVecs(i,:,:),regions,centroids,mergeID,modC,sThres,lConst,voxelInfo);
        % plot sensors
        for k=1:size(sensorPts,1)
            plot([sensorPts(k,1) sensorPts(k,3)], [sensorPts(k,2) sensorPts(k,4)], 'k', 'LineWidth',1.5 );
            hold on
        end
        
        % connect the sensor
        % define input&output points
        
%         endPoints = [min(currD(:,5))-0.001 max(currD(:,6))/2; max(currD(:,5))+0.001 max(currD(:,6))/2];
        endPoints = [min(currD(:,5))+0.002 max(currD(:,6))/2; max(currD(:,5))-0.002 max(currD(:,6))/2];
%         endPoints = [min(currD(:,5)) max(currD(:,6))/2; max(currD(:,5)) max(currD(:,6))/2];
        
        [slength,baseR,points, trueStrain, errorStrain] = createSensor(strVecs(i,:,:),mergeID,modC,stds,regions,sensorPts,senRegs,senAng,senMag,endPoints,method,voxelInfo);
        plot(points(:,1),points(:,2),'r','LineWidth',1.5 );
        
        Sensors(i).name = Files(i).name;
        Sensors(i).points = points;
        Sensors(i).length = slength;
        Sensors(i).baseR = baseR;
        Sensors(i).totalStrain = trueStrain + errorStrain;
        Sensors(i).trueStrain = trueStrain;
        Sensors(i).errorStrain = errorStrain;
        
        for k=1:size(sensorPts,1)
            plot([sensorPts(k,1) sensorPts(k,3)], [sensorPts(k,2) sensorPts(k,4)], 'k', 'LineWidth',1.5 );
            hold on
        end
        axis equal
        
        
        % UPDATE THE DEFORMATION
        Deformation(i).clusters = mergeID;
        Deformation(i).angles = modC;
        Deformation(i).stds = stds;
        Deformation(i).vectors = squeeze(strVecs(i,:,:));
        Deformation(i).sensors = Sensors(i);
        Deformation(i).regions = regions;
        Deformation(i).voxelInfo = voxelInfo;
        




    end
    
end
    

     
     
     

