function [slength,baseR,points, trueStrain, errorStrain] = createSensor(strVecs,mergeID,modC,stds,regions,inputPts, senRegs,senAng,senMag, endPoints,method,voxelInfo )

% method = function to connect sensors
% 1 = distance
% 2 = cost
% 3 = exhaustive optimum

% connects the sensor by using the min euclidian distance method
% % linear resistivity/strain coefficient 
% G = 2; % [2kOhm/mm] % for 2cm sensor, might change w.r.t sensor length actually
% K = 70; % [70 Ohm/mm] base resistivity of the sensor

% THIS ONE IS UPDATED!!!!
G = 0.6; % [0.6kOhm/mm] % for 2cm sensor, might change w.r.t sensor length actually
K = 37.5; % [37.5 Ohm/mm] base resistivity of the sensor

surfaceSize = voxelInfo(1) / voxelInfo(4); 
finalIndex = (voxelInfo(1) - surfaceSize) - 1;

% go through inputPts as well
    for i=1:size(inputPts,1)
        
        % make sure 1st point is always on the west of 2nd point
        if inputPts(i,1) > inputPts(i,3)
            tmp = inputPts(i,3:4);
            inputPts(i,3:4) = inputPts(i,1:2);
            inputPts(i,1:2) = tmp;
        end
            
        
    end

% the input and output points
startPt = endPoints(1,:);
endPt = endPoints(2,:);

% used sensors index
usedSensors = zeros(size(inputPts,1),1);

% % get rid of 0,0 points
% sensorPts = inputPts(inputPts(:,2) ~= 0,:);
% append the end point as well

% sensorPts = [inputPts; endPt endPt];
sensorPts = inputPts;

% vectors
currV = squeeze(strVecs);

% go through all sensor parts to sort them
    for i=1:size(sensorPts,1)
        
        % make sure 1st point is always on the west of 2nd point
        if sensorPts(i,1) > sensorPts(i,3)
            tmp = sensorPts(i,3:4);
            sensorPts(i,3:4) = sensorPts(i,1:2);
            sensorPts(i,1:2) = tmp;
        end
            
        
    end
    
    % find sensors that are in between start and enp points
%     senMag = senMag(sensorPts(:,1) > startPt(1) & sensorPts(:,3) < endPt(1),:);
%     sensorPts = sensorPts(sensorPts(:,1) > startPt(1) & sensorPts(:,3) < endPt(1),:);
    
% the reference point where sensor will be connected
refPt = [startPt startPt];
% circuitComplete is true when input is connected to output
cirComp = 0;
% final sensor connection points
points = refPt(1:2);
% vector strength threshold
sThres = 5e-6;

if method ~= 3 % FOR DISTANCE OR COST FUNCTION 
    while cirComp == 0

        
        % candidate sensors
        candCr = (senMag > sThres & sensorPts(:,1) > startPt(1) & sensorPts(:,3) < endPt(1));
        
        candPts = sensorPts(candCr,: ); 
        % find the magnitudes of each sensor
        magVecs = senMag(candCr);      
        % find sensors on your east completely    
        closeVecs = candPts(candPts(:,1)>refPt(3),:);
        % update mag vectors wrt distance
        magVecs = magVecs(candPts(:,1)>refPt(3));        
        % find each possible sensor's distance
        dissM = sqrt( (closeVecs(:,1) - refPt(3)).^2 + (closeVecs(:,2) - refPt(4)).^2 );
        % find the length of each sensor
        lengthM = sqrt( (closeVecs(:,1)-closeVecs(:,3)).^2 + (closeVecs(:,2)-closeVecs(:,4)).^2 );

        
        % check ?f we completed the circuit
        if isempty(closeVecs) == 1
            cirComp = 1;
            break;
        end


        if method == 1 % do the DISTANCE FUNCTION
            refPt = closeVecs(dissM == min(dissM),:);  
        end

        if method == 2 % do the COST FUNCTION
            % find the min. costing sensor, cost = distance_to_sensor/sensor_length
            % distance_to_sensor = connection legnth, so
            % cost = connection_length/sensor_length
            costM = dissM./magVecs;  
            refPt = closeVecs(costM == min(costM),:);
        end


        % append the points
        points = [points; refPt(1:2); refPt(3:4)];
        % mark this sensor to be used
        for i=1:size(inputPts,1)
            if sum(inputPts(i,:) == refPt) == 4
                usedSensors(i) = 1;
                break;
            end
        end  

%         % check if we completed the circuit
%         if sum(refPt(1:2) == endPt) == 2
%             cirComp = 1;    
%         end
    end
else % FOR RANDOM SEARCH
    
    while cirComp == 0

         % candidate sensors
        candPts = sensorPts(senMag > sThres,: ); 
        
        % find sensors on your east completely    
        closeVecs = candPts(candPts(:,1)>refPt(3),:);
        % find each possible sensor's distance
        dissM = sqrt( (closeVecs(:,1) - refPt(3)).^2 + (closeVecs(:,2) - refPt(4)).^2 );
        % find the length of each sensor
        lengthM = sqrt( (closeVecs(:,1)-closeVecs(:,3)).^2 + (closeVecs(:,2)-closeVecs(:,4)).^2 );


        % check ?f we completed the circuit
        if isempty(closeVecs) == 1
            cirComp = 1;
            break;
        end

        % select a random next point
        randInd = randi([1 size(closeVecs,1)]);
        refPt = closeVecs(randInd,:);

        % append the points
        points = [points; refPt(1:2); refPt(3:4)];
        % mark this sensor to be used
        for i=1:size(inputPts,1)
            if sum(inputPts(i,:) == refPt) == 4
                usedSensors(i) = 1;
                break;
            end
        end  

%         % check if we completed the circuit
%         if sum(refPt(1:2) == endPt) == 2
%             cirComp = 1;    
%         end
    end
    
end


% % remove the double end point
% points = points(1:end-1,:);

% append the end point
points = [points; endPt];

% now get the true strain over all the sensors
trueStrain = sum(senMag(usedSensors==1)*1000*G);

% now find the error due to connection lines
errorStrain = 0;

for i=1:size(points,1)/2
   ind = (i*2)-1;
   
   % find the connection line end points
   connPt = [points(ind,:), points(ind+1,:)];
   % find connection line length
   connL = sqrt( (connPt(1) - connPt(3))^2 + (connPt(2) - connPt(4))^2 );
   % find connection line angle
   connAng = mod(atan2((connPt(4)-connPt(2)),(connPt(3)-connPt(1))),2*pi);
   % now find intermediate points on the line ( except the end points
   inCnt = floor(connL / 0.0015) ;
   
   if inCnt > 0 % if there are intermediate points, find them
       totCnt = 1:inCnt;
       newPts = [connPt(1) + (totCnt*0.0015*cos(connAng))' connPt(2) + (totCnt*0.0015*sin(connAng))' ]; 
       
       % for all these points. find the neighborhood and find the strain
       for k=1:size(newPts,1)
           myPt = newPts(k,:);          
           myPt = repmat(myPt,size(currV,1),1);
           % find closest point to our point
           dists = sqrt( (currV(:,5)-myPt(:,1)).^2 + (currV(:,6)-myPt(:,2)).^2 );      
           % find that closest point's region and average strain angle and
           % magnitude
           
           if size(currV(dists < (0.0015/2)*sqrt(2),1),1) > 0
               
               % select a voxel from the candidates and go with it ( mode
               % selects the smallets if all candidates are equally
               % frequent
%                selectVoxInd = mode(currV(dists < (0.0015/2)*sqrt(2),1)-finalIndex);
               [minDist,selectVoxInd] = min(dists);
               % find the strain magnitude in that voxel
               regVec = currV(selectVoxInd,:);
               clsMag = sqrt(regVec(:,2).^2 + regVec(:,3).^2 );
               % find the cluster of that voxel
               clsClus = mergeID(selectVoxInd);
               % find the voxels angle
%                clsAng = modC(clsClus);
                clsAng = mod(atan2(regVec(:,3),regVec(:,2)),2*pi);
               % find the std dev of angle in that cluster
               clsAngDev = deg2rad(stds(clsClus));
               % find the region that voxel belongs to
               clsReg = regions(selectVoxInd);

               
%                clsClus = mode(mergeID(currV(dists < (0.0015/2)*sqrt(2),1)-finalIndex));
%                clsAng = modC(clsClus);
%                clsAngDev = deg2rad(stds(clsClus));
%                % this one is always percentage of strain, we need to convert it
%                % into total length of strain
%                clsReg = unique(regions((mergeID == clsClus)&&(currV(dists < (0.0015/2)*sqrt(2),1)-finalIndex)));
%                regVecs = (currV(regions == clsReg,:));
%                clsMag = mean( sqrt(regVecs(:,2).^2 + regVecs(:,3).^2 ) );
% %                clsMag = mean(sqrt((currV((currV(dists < (0.0015/2),1)-3599),2)).^2+(currV((currV(dists < (0.0015/2),1)-3599),3)).^2));           
%                % average strain in that region
%                
%                avgMag = mean(sqrt(currV(mergeID == clsReg,2).^2+currV(mergeID == clsReg,3).^2));
%                % total strain in length
%                errLen =  (clsMag/(0.0015))*avgMag*(0.0015);

                % strain vector
                strV = clsMag*0.0015;
                % sensor piece
                sensP = 1;
                
                % check for the correct projection
                
%                 if connAng >= 0 && connAng <= pi/2
%                     a = 12;
%                 end
%                 
%                 if connAng >= pi/2 && connAng <= pi
%                     a = 12;
%                 end
%                 
%                 if connAng >= pi && connAng <= 3*pi/2
%                     a = 12;
%                 end
%                 
%                 if connAng >= 3*pi/2 && connAng <= 2*pi
%                     a = 12;
%                 end
                
                clsProj = 1;
                if clsAng >= connAng
                    clsProj = strV*cos(clsAng - connAng);
                    if connAng >= 0 && connAng <= pi/2 % I
                        if clsProj >= 0
                            clsProj = clsProj; % projection is in reg. I
                        else
                            clsProj = 0; % projection is in reg. III
                        end
                    end
                    
                    if connAng >= 3*pi/2 && connAng <= 2*pi % IV
                        % projection will always be + and in IV
                        clsProj = clsProj * cos(2*pi - connAng);
                    end                    
                else
                    clsProj = strV*cos(connAng - clsAng);
                    
                    if connAng >= 0 && connAng <= pi/2 % I
                        % projection will always be + and in I
                        clsProj =  clsProj;
                    end
                    
                    if connAng >= 3*pi/2 && connAng <= 2*pi % IV
                        if clsProj >= 0 % projection is in IV
                            clsProj = clsProj * cos(2*pi - connAng); 
                        else
                            % projection is in reg II
                            clsProj = abs(clsProj * cos(connAng - 3*pi/2));
                        end
                        
                    end
                end

                clsProj = clsProj * 1000 * G;

% 
%                 
%                 clsProj = 0;
%                 
%                 if clsAng > connAng
%                     if connAng >= 0 && connAng <= pi/2
%                         if (clsAng - connAng >= 0) && (clsAng - connAng <= pi/2)
%                             clsProj = strV*sensP*cos(clsAng - connAng);
%                         end
%                         if (clsAng - connAng >= 3*pi/2) && (clsAng - connAng <= 2*pi)
%                             clsProj = strV*sensP*cos(clsAng - connAng);
%                         end
%                     end
%                     
%                     if connAng >= pi/2 && connAng <= pi
%                         if (clsAng - connAng >= 0) && (clsAng - connAng <= pi/2)
%                             clsProj = strV*sensP*cos(clsAng - connAng)*cos(connAng-pi/2);
%                         end
%                         if (clsAng - connAng >= 3*pi/2) && (clsAng - connAng <= 2*pi)
%                             clsProj = strV*sensP*cos(clsAng - connAng)*cos(connAng-pi/2);
%                         end                        
%                     end
%                     
%                     if connAng >= pi && connAng <= 3*pi/2
%                         clsProj = 0;                      
%                     end
%                     
%                     if connAng >= 3*pi/2 && connAng <= 2*pi
%                         if (clsAng - connAng >= 0) && (clsAng - connAng <= pi/2)
%                             clsProj = strV*sensP*cos(clsAng - connAng)*cos(connAng);
%                         end
%                         if (clsAng - connAng >= 3*pi/2) && (clsAng - connAng <= 2*pi)
%                             clsProj = strV*sensP*cos(clsAng - connAng)*cos(connAng);
%                         end                        
%                     end                    
%                 else
%                     
%                     if connAng >= 0 && connAng <= pi/2
%                         clsProj = strV*sensP*cos(connAng-clsAng);
%                     end
%                     
%                     if connAng >= pi/2 && connAng <= pi
%                         if (connAng - clsAng >= 0) && (connAng - clsAng <= pi/2)
%                             clsProj = strV*sensP*cos(connAng-clsAng)*cos(connAng - pi/2);
%                         end
%                     end
%                     
%                     if connAng >= pi && connAng <= 3*pi/2
%                         clsProj = 0;                      
%                     end
%                     
%                     if connAng >= 3*pi/2 && connAng <= 2*pi
%                         if ( connAng - clsAng >= 0) && ( connAng - clsAng <= pi/2)
%                             clsProj = strV*sensP*cos(connAng - clsAng)*cos(connAng);
%                         end
%                         if ( connAng - clsAng >= 3*pi/2) && (connAng - clsAng <= 2*pi)
%                             clsProj = strV*sensP*cos(connAng-clsAng)*cos(connAng);
%                         end                        
%                     end   
%                     
%                 end
%                 
%                 clsProj = clsProj*1000*G;
                
%                 errLen = clsMag*0.0015;
                
                % OUR SENSOR IS SENSITIVE TO POSITIVE STRAIN SO WE NEED TO
                % GET THE POSITIVE COMPONENTS OF THE STRAIN W.R.T. STRAIN
                % DIRECTION
                                
                % do the vector projection
%                 clsProj = abs(errLen*cos(connAng-clsAng))*1000*G;
                
%                 % region 1 of unit circle: all positive
%                 if connAng >= 0 && connAng <= pi/2
%                     magConst = 1;
%                 end
% 
%                 % region 2 of unit circle: y positive
%                 if connAng >= pi/2 && connAng <= pi
%                     magConst = abs(sin(connAng));
%                 end
% 
%                 % region 3 of unit circle: all negative
%                 if connAng >= pi && connAng <= (3*pi)/2
%                     magConst = 0;
%                 end
% 
%                 % region 4 of unit circle: x positive
%                 if connAng >= (3*pi)/2 && connAng <= 2*pi
%                     magConst = abs(cos(connAng));
%                 end
%                 
%                 clsProj = clsProj*magConst;
                

                
                % IT COULD BE THE CASE THAT CONNECTION LUCKILY GOES THROUGH
                % A SIMILAR DIRECTION REGION,SO IT WONT BE ERROR.
                % WE CHECK IT HERE                            
                
                clsAngDev = deg2rad(10);
%                 if (mod(clsAng+clsAngDev,2*pi) > connAng) && (mod(clsAng-clsAngDev,2*pi) < connAng)
                if mod((connAng-clsAng),2*pi) < clsAngDev || mod((clsAng-connAng),2*pi) < clsAngDev
                    % THEN THIS ONE IS ACTUALLY A TRUE STRAIN
                    trueStrain = trueStrain + clsProj; 
                    
                else
                    % NOPE, STILL ERROR STRAIN
                    errorStrain = errorStrain + clsProj; 
                end
              
           end
       end
       
   else
       
   end
   
   
   
end

% now calculate the sensor length and base resistivity

slength = 0;
beg_pt = points(1,:);

for i=2: size(points,1)
    
    currP = points(i,:);
    currL = sqrt( (beg_pt(1)-currP(1) )^2 + (beg_pt(2)-currP(2))^2 );
    
    slength = slength + currL;
    beg_pt = currP;
   
end

baseR = slength*K;



end