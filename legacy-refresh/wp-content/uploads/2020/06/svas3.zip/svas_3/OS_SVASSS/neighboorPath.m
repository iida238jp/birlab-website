% takes in strain vector space and feature vectors to define distinct
% neighboor regions

% strVec = strain vector matrix
% mergeID = k-means clustering indices
% strInd = vector magnitude indices
% scaleThr = threshold size of the neighboorhood region
% voxelInfo = [totalSize, xSize, ySize, zSize]

function [regions,centroids] = neighboorPath(strVec,mergeID,strInd,scaleThr, voxelInfo)

        surfaceSize = voxelInfo(1) / voxelInfo(4);
        xSize = voxelInfo(2);
        ySize = voxelInfo(3);


        % try the neighborhood region 
        regions = zeros(surfaceSize,1);
        
        regions(strInd == 1) = -1;
        % north boundary
        NB = surfaceSize;
        % south boundary
        SB = 0;

        % initial N. index
        nIndex = 1;
        regions(1) = 1;

        for j=2:size(strVec,2)

            % side boundary indices
            WB = floor((j-1)/xSize)*xSize;
            EB = WB + (xSize+1);

            % check neighboors
%             
%             localNs = [];
%             
%             % WEST
%             if j-1 > WB && j-1 > SB
%                 localNs = [localNs;j-1];
%             end
%             % SOUTH WEST
%             if j-31 > SB && j-31 > WB - 30
%                 localNs = [localNs;j-31];
%             end
%             % SOUTH
%             if j-30 > SB
%                 localNs = [localNs;j-30];
%             end
%             % SOUTH EAST
%             if j-29 > SB && j-29 < EB - 30
%                 localNs = [localNs;j-29];
%             end
%             % EAST
%             if j+1 < EB && j+1 < NB
%                 localNs = [localNs;j+1];
%             end
%             % NORTH EAST
%             if j+31 < NB && j+31 < EB + 30
%                 localNs = [localNs;j+31];
%             end
%             % NORTH
%             if j+30 < NB
%                 localNs = [localNs;j+30];
%             end
%             % NORTH WEST
%             if j+29 < NB && j+29 > WB + 30
%                 localNs = [localNs;j+29];
%             end
%             
%             % my neighboors with my cluster id
%             sClusters = localNs(mergeID(localNs) == mergeID(j));
%             % add my place to same cluster neighboors as well
%             sClusters = [j;sClusters];
%             
%             regions(sClusters) = min(regions(sClusters));

            % WEST
            if j-1 > WB && j-1 > SB
               if mergeID(j) == mergeID(j-1)
                    if regions(j-1) == 0
                        nIndex = nIndex + 1;
                        regions(j) = nIndex;
                        continue;
                    else
                        if regions(j-1) == -1
                            continue;
                        else
                            regions(j) = regions(j-1);
                            continue;
                        end
                    end
               end
            end
            
            % SOUTH WEST
            if j-(xSize+1) > SB && j-(xSize+1) > WB - xSize
               if mergeID(j) == mergeID(j-(xSize+1))
                    if regions(j-(xSize+1)) == 0
                        nIndex = nIndex + 1;
                        regions(j) = nIndex;
                        continue;
                    else
                        if regions(j-(xSize+1)) == -1
                            continue;
                        else
                            regions(j) = regions(j-(xSize+1));
                            continue;
                        end
                    end
               end
            end  
            
            %SOUTH
            if j-xSize > SB
                if mergeID(j) == mergeID(j-xSize)
                    if regions(j-xSize) == 0
                        nIndex = nIndex + 1;
                        regions(j) = nIndex;
                        continue;
                    else
                        if regions(j-xSize) == -1
                            continue;
                        else
                            regions(j) = regions(j-xSize);
                            continue;
                        end
                    end
                end
            end
                                 
            % SOUTH EAST
            if j-(xSize-1) > SB && j-(xSize-1) < EB - xSize
               if mergeID(j) == mergeID(j-(xSize-1))
                    if regions(j-(xSize-1)) == 0
                        nIndex = nIndex + 1;
                        regions(j) = nIndex;
                        continue;
                    else
                        if regions(j-(xSize-1)) == -1
                            continue;
                        else
                            regions(j) = regions(j-(xSize-1));
                            continue;
                        end
                    end
               end
            end  
            

            % EAST  
            if j+1 < EB && j+1 < NB
                if mergeID(j) == mergeID(j+1)
                    if regions(j+1) == 0
                        nIndex = nIndex + 1;
                        regions(j) = nIndex;
                        continue;
                    else
                        if regions(j+1) == -1
                            continue;
                        else
                            regions(j) = regions(j+1);
                            continue;
                        end
                    end
                end
            end
            
            % NORTH EAST
            if j+(xSize+1) < NB && j+(xSize+1) < EB + xSize
                if mergeID(j) == mergeID(j+(xSize+1))
                    if regions(j+(xSize+1)) == 0
                        nIndex = nIndex + 1;
                        regions(j) = nIndex;
                        continue;
                    else
                        if regions(j+(xSize+1)) == -1
                            continue;
                        else
                            regions(j) = regions(j+(xSize+1));
                            continue;
                        end
                    end
                end
            end
            
            % NORTH
            if j+xSize < NB
                if mergeID(j) == mergeID(j+xSize)
                    if regions(j+xSize) == 0
                        nIndex = nIndex + 1;
                        regions(j) = nIndex;
                        continue;
                    else
                        if regions(j+xSize) == -1
                            continue;
                        else
                            regions(j) = regions(j+xSize);
                            continue;
                        end
                    end
                end
            end
            
            % NORTH WEST
            if j+(xSize-1) < NB && j+(xSize-1) > WB + xSize
                if mergeID(j) == mergeID(j+(xSize-1))
                    if regions(j+(xSize-1)) == 0
                        nIndex = nIndex + 1;
                        regions(j) = nIndex;
                        continue;
                    else
                        if regions(j+(xSize-1)) == -1
                            continue;
                        else
                            regions(j) = regions(j+(xSize-1));
                            continue;
                        end
                    end
                end
            end

            % if it comes here, it means this is a new neighborhood
            nIndex = nIndex + 1;
            regions(j) = nIndex;

        end
        
        
        for j=2:size(strVec,2)

            % side boundary indices
            WB = floor((j-1)/xSize)*xSize;
            EB = WB + (xSize+1);
                %             
            localNs = [];
            
            % WEST
            if j-1 > WB && j-1 > SB
                localNs = [localNs;j-1];
            end
            % SOUTH WEST
            if j-(xSize+1) > SB && j-(xSize+1) > WB - xSize
                localNs = [localNs;j-(xSize+1)];
            end
            % SOUTH
            if j-xSize > SB
                localNs = [localNs;j-xSize];
            end
            % SOUTH EAST
            if j-(xSize-1) > SB && j-(xSize-1) < EB - xSize
                localNs = [localNs;j-(xSize-1)];
            end
            % EAST
            if j+1 < EB && j+1 < NB
                localNs = [localNs;j+1];
            end
            % NORTH EAST
            if j+(xSize+1) < NB && j+(xSize+1) < EB + xSize
                localNs = [localNs;j+(xSize+1)];
            end
            % NORTH
            if j+xSize < NB
                localNs = [localNs;j+xSize];
            end
            % NORTH WEST
            if j+(xSize-1) < NB && j+(xSize-1) > WB + xSize
                localNs = [localNs;j+(xSize-1)];
            end
            
            % my neighboors with my cluster id
            sClusters = localNs(mergeID(localNs) == mergeID(j));
            % add my place to same cluster neighboors as well
            sClusters = [j;sClusters];
            
            regions(sClusters) = min(regions(sClusters));

        end
        
        revOr = sort((2:size(strVec,2)),'descend');
        % now do a final touch from reverse order
        for k=1:size(revOr,2)
            j = revOr(k);
            
                        % side boundary indices
            WB = floor((j-1)/xSize)*xSize;
            EB = WB + xSize+1;
                %             
            localNs = [];
            
            % WEST
            if j-1 > WB && j-1 > SB
                localNs = [localNs;j-1];
            end
            % SOUTH WEST
            if j-(xSize+1) > SB && j-(xSize+1) > WB - xSize
                localNs = [localNs;j-(xSize+1)];
            end
            % SOUTH
            if j-xSize > SB
                localNs = [localNs;j-xSize];
            end
            % SOUTH EAST
            if j-(xSize-1) > SB && j-(xSize-1) < EB - xSize
                localNs = [localNs;j-(xSize-1)];
            end
            % EAST
            if j+1 < EB && j+1 < NB
                localNs = [localNs;j+1];
            end
            % NORTH EAST
            if j+(xSize+1) < NB && j+(xSize+1) < EB + xSize
                localNs = [localNs;j+(xSize+1)];
            end
            % NORTH
            if j+xSize < NB
                localNs = [localNs;j+xSize];
            end
            % NORTH WEST
            if j+(xSize-1) < NB && j+(xSize-1) > WB + xSize
                localNs = [localNs;j+(xSize-1)];
            end
            
            % my neighboors with my cluster id
            sClusters = localNs(mergeID(localNs) == mergeID(j));
            % add my place to same cluster neighboors as well
            sClusters = [j;sClusters];
            
            regions(sClusters) = min(regions(sClusters));
            
        end
        
        % now modify neighboorhoods according to vector magnitudes       
        regions(strInd == 1) = 0;
        
        % now trim the neighborhood regions smaller than scaleThreshold
        nHoods = unique(regions);
        
        for i=1:size(nHoods)
            
            totalArea = regions(regions == nHoods(i));
            
            if size(totalArea,1) < scaleThr
                regions(regions == nHoods(i)) = 0;
            end
            
        end
        
        regions(regions == -1) =0;

        
        % now get the final regions ( shrink the set )
        
        currStat = unique(regions);
        
        for i=1:max(currStat)
            
            if i > max(currStat)
                break;
            end
            
           totalArea = regions(regions == i);
           
           if size(totalArea,1) == 0
                regions(regions == min(currStat(currStat > i))) = i;
           end
           currStat = unique(regions);
            
        end
        
        % find the centroids
        centroids = zeros(size(currStat,1),2);
        
        for i=1:size(currStat,1)
            
            if(currStat(i) ~= 0)
                vecs = strVec(1,regions == currStat(i),:);
                centroids(i,:) = [mean(vecs(1,:,5)) mean(vecs(1,:,6))];
            else
                centroids(i,:) = [0,0];
            end
         
            
        end
        
        
        
end