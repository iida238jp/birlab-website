function [resTrueStrain,resErrorStrain] = testSensors(Deformation,theSensor)

%mergeID,modC,vecs,Sensors,regions

% linear resistivity/strain coefficient 
G = 2; % used to be [2kOhm/mm]

%this one takes one selected sensor placement, and shape and tests it in
%other deformations

        % UPDATE THE DEFORMATION
%        Deformation(i).clusters = mergeID;
%        Deformation(i).angles = modC;
%        Deformation(i).vectors = squeeze(strVecs(i,:,:));
%        Deformation(i).sensors = Sensors;
%        Deformation(i).regions = regions;
%        Deformation(i).voxelInfo = voxelInfo;   

% mergeID = clusters with respect to strain direction angle
% modC = the strain direction angles
% vecs = complete matrix of voxels with position and strain information
% Sensors = struct, with sensor points and strain information
% regions = total neighborhoods in the complete deformation shape
% voxelInfo = [totalSize, xSize, ySize, zSize]

resTrueStrain = [];
resErrorStrain = [];



for i = 1 : size(Deformation,2)
    
    % get the current Deformation
    currDef = Deformation(i);
    
    % deformation voxel info
    surfaceSize = currDef.voxelInfo(1) / currDef.voxelInfo(4); 
    finalIndex = (currDef.voxelInfo(1) - surfaceSize) - 1;
    
    % reset error and true strains
    errorStrain = 0;
    trueStrain = 0;
    
    % get the points from the chosen sensor and go through all the vectors
    % and find the total, true and error strain
    
    for j = 1: size(theSensor.points,1)-1
        
        % if j is odd, then we check connection points
        % if j is even, then we check sensor points
        
%         if mod(j,2) == 1 
        % CHECKING THE CONNECTION POINTS
        
            connPt = [theSensor.points(j,:), theSensor.points(j+1,:)];
            % find connection line length
            connL = sqrt( (connPt(1) - connPt(3))^2 + (connPt(2) - connPt(4))^2 );
            % find connection line angle
            connAng = mod(atan2((connPt(4)-connPt(2)),(connPt(3)-connPt(1))),2*pi);
            % now find intermediate points on the line ( except the end points
            inCnt = floor(connL / 0.0015) ;

            if inCnt > 0 % if there are intermediate points, find them
                
                % go through the intermediate points
                totCnt = 1:inCnt;
                newPts = [connPt(1) + (totCnt*0.0015*cos(connAng))' connPt(2) + (totCnt*0.0015*sin(connAng))' ]; 
                
                % fetch the vectors from the current deformation
                currV = currDef.vectors;
                
                % for all these points. find the neighborhood and find the strain
                for k=1:size(newPts,1)
                    
                    % get the point
                    myPt = newPts(k,:);  
                    % enlarge it 
                    myPt = repmat(myPt,size(currV,1),1);                    
                    % find closest point to our point
                    dists = sqrt( (currV(:,5)-myPt(:,1)).^2 + (currV(:,6)-myPt(:,2)).^2 );      

                    % if we find a close point to ours smaller than half
                    % the size of a voxel, then:
                    if size(currV(dists < (0.0015/2)*sqrt(2),1),1) > 0
                        % find that closest point's cluster and average strain angle and
                        % region
%                         clsClus = mode(currDef.clusters(currV(dists < (0.0015/2)*sqrt(2),1)-finalIndex));
%                         clsAng = currDef.angles(clsClus);   
%                         clsAngDev = deg2rad(currDef.stds(clsClus));
%                         clsReg = mode(currDef.regions(currV(dists < (0.0015/2)*sqrt(2),1)-finalIndex));
%                         % now from the region, find the average magnitude
%                         % there.
%                         regVecs = (currV(currDef.regions == clsReg,:));
%                         clsMag = mean( sqrt(regVecs(:,2).^2 + regVecs(:,3).^2 ) );
%                         % this one is always percentage of strain, we need to convert it
%                         % into total length of strain
%                         errLen = clsMag*0.0015;
%                              
%                         % do the vector projection on our point
%                         clsProj = abs(errLen*cos(connAng-clsAng))*1000*G;     
                        
                        
                       % select a voxel from the candidates and go with it ( mode
                       % selects the smallets if all candidates are equally
                       % frequent
%                        selectVoxInd = mode(currV(dists < (0.0015/2)*sqrt(2),1)-finalIndex);
                       [minDist,selectVoxInd] = min(dists);
                       % find the strain magnitude in that voxel
                       regVec = currV(selectVoxInd,:);
                       clsMag = sqrt(regVec(:,2).^2 + regVec(:,3).^2 );
                       % find the cluster of that voxel
                       clsClus = currDef.clusters(selectVoxInd);
                       % find the voxels angle
%                        clsAng = currDef.angles(clsClus);
                       clsAng = mod(atan2(regVec(:,3),regVec(:,2)),2*pi);
                       % find the std dev of angle in that cluster
                       clsAngDev = deg2rad(currDef.stds(clsClus));
                       % find the region that voxel belongs to
                       clsReg = currDef.regions(selectVoxInd);

                       
                       
                       % strain vector
                        strV = clsMag*0.0015;

                        clsProj = 1;
                        if clsAng >= connAng
                            clsProj = strV*cos(clsAng - connAng);
                            if connAng >= 0 && connAng <= pi/2 % I
                                if clsProj >= 0
                                    clsProj = clsProj; % projection is in reg. I
                                else
                                    clsProj = 0; % projection is in reg. III
                                end
                            end

                            if connAng >= 3*pi/2 && connAng <= 2*pi % IV
                                % projection will always be + and in IV
                                clsProj = clsProj * cos(2*pi - connAng);
                            end                    
                        else
                            clsProj = strV*cos(connAng - clsAng);

                            if connAng >= 0 && connAng <= pi/2 % I
                                % projection will always be + and in I
                                clsProj =  clsProj;
                            end

                            if connAng >= 3*pi/2 && connAng <= 2*pi % IV
                                if clsProj >= 0 % projection is in IV
                                    clsProj = clsProj * cos(2*pi - connAng); 
                                else
                                    % projection is in reg II
                                    clsProj = abs(clsProj * cos(connAng - 3*pi/2));
                                end

                            end
                        end

                        clsProj = clsProj * 1000 * G;
                        
                        
                        
%                         % sensor piece
%                         sensP = 0.0015;
% 
%                         % check for the correct projection
% 
%                         clsProj = 0;
% 
%                         if clsAng > connAng
%                             if connAng >= 0 && connAng <= pi/2
%                                 if (clsAng - connAng >= 0) && (clsAng - connAng <= pi/2)
%                                     clsProj = strV*sensP*cos(clsAng - connAng);
%                                 end
%                                 if (clsAng - connAng >= 3*pi/2) && (clsAng - connAng <= 2*pi)
%                                     clsProj = strV*sensP*cos(clsAng - connAng);
%                                 end
%                             end
% 
%                             if connAng >= pi/2 && connAng <= pi
%                                 if (clsAng - connAng >= 0) && (clsAng - connAng <= pi/2)
%                                     clsProj = strV*sensP*cos(clsAng - connAng)*cos(connAng-pi/2);
%                                 end
%                                 if (clsAng - connAng >= 3*pi/2) && (clsAng - connAng <= 2*pi)
%                                     clsProj = strV*sensP*cos(clsAng - connAng)*cos(connAng-pi/2);
%                                 end                        
%                             end
% 
%                             if connAng >= pi && connAng <= 3*pi/2
%                                 clsProj = 0;                      
%                             end
% 
%                             if connAng >= 3*pi/2 && connAng <= 2*pi
%                                 if (clsAng - connAng >= 0) && (clsAng - connAng <= pi/2)
%                                     clsProj = strV*sensP*cos(clsAng - connAng)*cos(connAng-3*pi/2);
%                                 end
%                                 if (clsAng - connAng >= 3*pi/2) && (clsAng - connAng <= 2*pi)
%                                     clsProj = strV*sensP*cos(clsAng - connAng)*cos(connAng-3*pi/2);
%                                 end                        
%                             end                    
%                         else
% 
%                             if connAng >= 0 && connAng <= pi/2
%                                 clsProj = strV*sensP*cos(connAng-clsAng);
%                             end
% 
%                             if connAng >= pi/2 && connAng <= pi
%                                 if (connAng - clsAng >= 0) && (connAng - clsAng <= pi/2)
%                                     clsProj = strV*sensP*cos(connAng-clsAng)*cos(connAng - pi/2);
%                                 end
%                             end
% 
%                             if connAng >= pi && connAng <= 3*pi/2
%                                 clsProj = 0;                      
%                             end
% 
%                             if connAng >= 3*pi/2 && connAng <= 2*pi
%                                 if ( connAng - clsAng >= 0) && ( connAng - clsAng <= pi/2)
%                                     clsProj = strV*sensP*cos(connAng - clsAng)*cos(connAng-3*pi/2);
%                                 end
%                                 if ( connAng - clsAng >= 3*pi/2) && (connAng - clsAng <= 2*pi)
%                                     clsProj = strV*sensP*cos(connAng-clsAng)*cos(connAng-3*pi/2);
%                                 end                        
%                             end   
% 
%                         end
% 
%                         clsProj = clsProj*1000*G;
                        
%                         % OUR SENSOR IS SENSITIVE TO POSITIVE STRAIN SO WE NEED TO
%                         % GET THE POSITIVE COMPONENTS OF THE STRAIN W.R.T. STRAIN
%                         % DIRECTION
%                         % region 1 of unit circle: all positive
%                         % region 1 of unit circle: all positive
%                         if connAng >= 0 && connAng <= pi/2
%                             magConst = 1;
%                         end
% 
%                         % region 2 of unit circle: y positive
%                         if connAng >= pi/2 && connAng <= pi
%                             magConst = abs(sin(connAng));
%                         end
% 
%                         % region 3 of unit circle: all negative
%                         if connAng >= pi && connAng <= (3*pi)/2
%                             magConst = 0;
%                         end
% 
%                         % region 4 of unit circle: x positive
%                         if connAng >= (3*pi)/2 && connAng <= 2*pi
%                             magConst = abs(cos(connAng));
%                         end
% 
%                         clsProj = clsProj*magConst;
                        
                clsAngDev = deg2rad(10);
%                 if (mod(clsAng+clsAngDev,2*pi) > connAng) && (mod(clsAng-clsAngDev,2*pi) < connAng)
                if mod((connAng-clsAng),2*pi) < clsAngDev || mod((clsAng-connAng),2*pi) < clsAngDev
                    % THEN THIS ONE IS ACTUALLY A TRUE STRAIN
                    trueStrain = trueStrain + clsProj; 
                    
                else
                    % NOPE, STILL ERROR STRAIN
                    errorStrain = errorStrain + clsProj; 
                end
                        
%                         % check if this was a connection or sensor
%                         if mod(j,2) == 1 % THIS WAS A CONNECTION
%                             
%                             % IT MIGHT BE THE CASE IT GOES THROUGH CORRECT
%                             % REGION
%                             if ((clsAng+clsAngDev) > connAng) && ((clsAng-clsAngDev) < connAng)
%                                 % sum to the true strain
%                                 trueStrain = trueStrain + clsProj;                               
%                             else
%                                 % sum to the error strain
%                                 errorStrain = errorStrain + clsProj; 
%                             end
% 
%                         else % THIS WAS A SENSOR
%                            % IT MIGHT BE THE CASE IT GOES THROUGH CORRECT
%                             % REGION
%                             if ((clsAng+clsAngDev) > connAng) && ((clsAng-clsAngDev) < connAng)
%                                 % sum to the true strain
%                                 trueStrain = trueStrain + clsProj;                               
%                             else
%                                 % sum to the error strain
%                                 errorStrain = errorStrain + clsProj; 
%                             end
%                         end   
                    end
                end
            end

%         else
            
%         end
        
    end
    
    % find the error and true strains for each deformation
    resErrorStrain = [resErrorStrain; errorStrain];
    resTrueStrain = [resTrueStrain; trueStrain];
    
end


end