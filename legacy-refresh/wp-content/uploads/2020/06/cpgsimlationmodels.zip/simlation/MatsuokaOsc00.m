clear;
cla;

dt=0.01;
beta=2.2;
u0=1.0;
tau1=1/32;
tau2=1/2.656;
w12=-2;
w21=-2;

u1=1;
v1=0;
u2=0;
v2=0;
y1=1;
y2=0;

theta=0.5;

yall=[y1 y2];
for i=1:500
ud1=(-u1+w12*y2+u0)/tau1;
u1=u1+ud1*dt;
% vd1=(-v1+y1)/tau2;
% v1=v1+vd1*dt;
y1=max(0,u1-theta);

ud2=(-u2+w21*y1+u0)/tau1;
u2=u2+ud2*dt;
% vd2=(-v2+y2)/tau2;
% v2=v2+vd2*dt;
y2=max(0,u2-theta);
yall=[yall; y1 y2];
end

figure(1);
hold on;
plot(yall(:,1),'-r');
plot(yall(:,2),'-b');





