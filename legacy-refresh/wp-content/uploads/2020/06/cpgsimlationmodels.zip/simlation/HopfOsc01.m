clear;
cla;

dt=0.01;
alpha=1.0;
E=1.0;
tau1=1.0;

x=0.1;
y=0;

yall=[x y];
for i=1:5000
xd=(-alpha*(x^2+y^2-E)/E*x-y)/tau1;
x=x+xd*dt;
yd=(x)/tau1;
y=y+yd*dt;

yall=[yall; x y];
end

figure(1);
hold on;
plot(yall(:,1),yall(:,2),'-r');
%plot(yall(:,2),'-b');





