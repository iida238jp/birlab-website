clear;
clf;

dt=0.01;
beta=1.2;
u0=5.0;
tau1=1/32;
tau2=1/2.656;
w12=-2;
w21=-2;

S11=0.9;

u1=10;
v1=10;
u2=0;
v2=0;
y1=1;
y2=0;
u3=20;
v3=2;
u4=0;
v4=0;
y3=0;
y4=0;

yall=[y1 y2 y3 y4];
for i=1:400
ud1=(-u1+w12*y2-beta*v1+u0+S11*y3)/tau1;
u1=u1+ud1*dt;
vd1=(-v1+y1)/tau2;
v1=v1+vd1*dt;
y1=max(0,u1);

ud2=(-u2+w21*y1-beta*v2+u0+S11*y4)/tau1;
u2=u2+ud2*dt;
vd2=(-v2+y2)/tau2;
v2=v2+vd2*dt;
y2=max(0,u2);

ud3=(-u3+w12*y4-beta*v3+u0+S11*y1)/tau1;
u3=u3+ud3*dt;
vd3=(-v3+y3)/tau2;
v3=v3+vd3*dt;
y3=max(0,u3);

ud4=(-u4+w21*y3-beta*v4+u0+S11*y2)/tau1;
u4=u4+ud4*dt;
vd4=(-v4+y4)/tau2;
v4=v4+vd4*dt;
y4=max(0,u4);



yall=[yall; y1 y2 y3 y4];
end

figure(1);
subplot(2,1,1);
hold on;
plot(yall(:,1),'-r');
plot(yall(:,2),'-b');

subplot(2,1,2);
hold on;
plot(yall(:,3),'-r');
plot(yall(:,4),'-b');





