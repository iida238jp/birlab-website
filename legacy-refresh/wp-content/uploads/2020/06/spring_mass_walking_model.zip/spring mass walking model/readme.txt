spring mass walking model

Please read this file before implementing simulations under this folder.
This approach consists of 4 files:
1. spring_mass_walking.m
2. spring_mass_walking_grf.m
3. spring_mass_walking_return_map.m
4. readme.txt

These files aim to simulate the spring mass running model in the Matlab environment.
Trajectories and return map are plotted.