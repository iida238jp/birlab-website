rimless wheel model

Please read this file before implementing simulations under this folder.
This approach consists of 4 files:
1. rimless_wheel.m
2. rimless_wheel_grf.m
3. rimless_wheel_mwe.m
4. readme.txt

These files aim to simulate the rimless wheel model in the Matlab environment.
Return map and phase portrait trajectories are plotted.