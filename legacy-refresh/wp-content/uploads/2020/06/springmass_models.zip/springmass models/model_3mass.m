%% the simulatin is wrapped in function model_1mass()
function []= model_3mass()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% model_3mass.m                        
% author:	Xiaoxiang Yu 	
% date:     Octoboer, 2012  
% revised:  March 21, 2014
%
% This file is to simulate an actuated 1D spring-mass model consisting
% of three masses are two linear springs. A sinusoidal force applies on the
% top mass. There are six state variables in total, which are the position
% and velocity of each mass. 
% ode45 is applied for numerical computation.
%
% references: 
% [1] Yu, X. et al. (2014). Minimalistic models of an energy efficient vertical hopping robot, IEEE Transactions on Industrial Electronics, 61(2): 1053-1062.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% parameter description %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% amplitude A(N), frequency omega(rad/s) and offset phi(rad) of force F,
% F = A*cos(omega*t+phi)
A = 1;
omega = 20;
phi = 0;

% masses upper m1(kg), middle m2(kg) and lower m3(kg)
m1 = .1;
m2 = .5;
m3 = .1;

% upper spring stiffness constant k1(N/m), damping c1(Ns/m) and natural length L10(m)
k1 = 50;
c1 = 0.1;
L10 = 0;

% lower spring stiffness constant k2(N/m), damping c2(Ns/m) and  natural length L20(m)
k2 = 500;
c2 = .1;
L20 = .5;

% initial conditions: masses position y, 1*3 vector,(m) and masses velocity y_dot, 1*3 vector,(m/s)
y = [L20 L20 0];
y_dot = zeros(1,3);

% initial phase: 1 flight; 2 stance support, wrong phase will likely get a
% irregular behavior.
initialphase = 2;

%number of cycles of stumilation
ncycles =  20;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% don't modify the following codes

g = 9.81;
errorthreshold = 10^-4;
t_end=0;
TT = 0;
YY = y;
%% simulate ncycles steps
for j = 1:ncycles*2
    switch initialphase
        % flight phase
        case 1
            options=odeset('events',@events_flight, 'RelTol', errorthreshold);
            [T, Y] = ode45(@diff_func, [0 2], [y y_dot], options);
            
        % stance phase
        case 2
            options=odeset('events',@events_stance, 'RelTol', errorthreshold);
            [T, Y] = ode45(@diff_func, [0 2], [y y_dot], options);
    end
    
    if ~isreal(Y) || (max(Y(:)) > (L10 + L20)*10) || (min(Y(1:end/2)) < -errorthreshold)
        disp('Values are out of reasonable range.');
        break;
    end
    
    % store data
    TT = [TT; t_end+T];
    YY = [YY; Y(:,1:3)];

    % update variable
    t_end = t_end+T(end);
    y = Y(end,1:3);
    y_dot = Y(end,4:6);
    if initialphase == 1
        y(3) = 0;
        y_dot(3) = 0;
    end
    
    % switching between phases
    initialphase = 3 - initialphase;
end
display(['Simulation stops at time ', num2str(t_end), 's.']);

% play animation
playanimation(TT, YY);

%% EoM definition
function [value,isterminal,direction] = events_flight(~,y)
    if isreal(y(3))
        value = y(3);
    else
        value = -1;
    end
    isterminal=1;
    direction = -1;
end

function [value,isterminal,direction] = events_stance(~,y)
    if isreal(y(2))
        value = m3*g-(y(2)-L20)*k2;
    else
        value = -1;
    end
    isterminal=1;
    direction = -1;
end

% differential equeations
function dy = diff_func(t,y)
    f = A*cos(omega*(t_end+t)+phi);
    
    dy = zeros(6,1);
    dy(1:3) = y(4:6);
    if initialphase == 1 || initialphase == 0
        dy(4:6) = [-(y(1)-y(2)-L10)*k1/m1-g+f/m1-c1*(y(4)-y(5))/m1, (y(1)-y(2)-L10)*k1/m2-g-(y(2)-y(3)-L20)*k2/m2+c1*(y(4)-y(5))/m2-c2*(y(5)-y(6))/m2 (y(2)-y(3)-L20)*k2/m3+c2*(y(5)-y(6))/m3-g];
    end
    if initialphase == 2
        dy(4:6) = [-(y(1)-y(2)-L10)*k1/m1-g+f/m1-c1*(y(4)-y(5))/m1, (y(1)-y(2)-L10)*k1/m2-g-(y(2)-y(3)-L20)*k2/m2+c1*(y(4)-y(5))/m2-c2*(y(5)-y(6))/m2 0];
    end
end

%% visualization
function playanimation(TT, YY)
    
    figure;
    h2 = subplot(4,2,2);
    h3 = subplot(4,2,4);
    h4 = subplot(4,2,6);
    h5 = subplot(4,2,8);
    h1 = subplot(4,2,[1 3 5 7]);
    
    if omega ~= 0
        timewindow = 8*pi/omega;
    else
        timewindow = 5;
    end
    timestep = timewindow/100;
    
    F = A*cos(omega*TT+phi);
    Y1limit = [-max(YY(:,1))*.1 max(YY(:,1))*1.2];
    
    framestart = 1;
    tstart = 0;
    frame = 1;
    for i = 1:TT(end)/timestep
        while timestep * i > TT(frame)
            frame = frame + 1;
        end
        if TT(frame) >= tstart + timewindow
            framestart = frame;
            tstart = tstart + timewindow;
        end
 
        hold(h1, 'off');
        plot(h1, [0, 0], [YY(frame,2) YY(frame,3)], 'g', 'linewidth', 3);
        hold(h1, 'on');
        plot(h1, [0, 0], [YY(frame,1) YY(frame,2)], 'color', [.5 .5 .5], 'linewidth', 4);
        plot(h1, [0, 0], [YY(frame,1) YY(frame,1)], 'o', 'markersize', 10, 'markerfacecolor', [1 0 0], 'markeredgecolor', [0 0 0]);
        plot(h1, [0, 0], [YY(frame,2) YY(frame,2)], 's', 'markersize', 15, 'markerfacecolor', [0 0 1], 'markeredgecolor', [0 0 0]);
        plot(h1, [0, 0], [YY(frame,3) YY(frame,3)], 's', 'markersize', 15, 'markerfacecolor', [1 0 1], 'markeredgecolor', [0 0 0]);
        plot(h1, [-.35 .35], [YY(frame,3) YY(frame,3)], 'k', 'linewidth',3);
        plot(h1, [-4 4], [0 0], 'k--', 'linewidth',2);
        text(-3.5,1.1*max(YY(:,1)),[num2str(TT(frame),'%.2f'),'s'], 'fontsize', 15);
       if F(frame) >= 0
            arrow = '\uparrow';
        else
            arrow = '\downarrow';
        end
        if F(frame) ~= 0
            text(.5,YY(frame,1),[arrow, 'f'],'fontsize',ceil(30*abs(F(frame))/max(abs(F))));
        end
        ylabel(h1, 'height (m)');
        set(h1, 'xlim', [-4 4], 'ylim', Y1limit, 'xtick', []);
      
        plot(h2, TT(framestart:frame), F(framestart:frame), 'k', 'linewidth', 2);
        set(h2, 'xlim', [tstart tstart+timewindow], 'box', 'on', 'xtick', []);
        ylabel(h2, 'f (N)');
        grid(h2, 'on');

        plot(h3, TT(framestart:frame), YY(framestart:frame,1), 'r', 'linewidth', 2);
        set(h3, 'xlim', [tstart tstart+timewindow], 'box', 'on', 'xtick', []);
        ylabel(h3, 'x_1 (m)');
        grid(h3, 'on');

        plot(h4, TT(framestart:frame), YY(framestart:frame,2), 'b', 'linewidth', 2);
        set(h4, 'xlim', [tstart tstart+timewindow], 'box', 'on', 'xtick', []);
        ylabel(h4, 'x_2 (m)');
        grid(h4, 'on');

        plot(h5, TT(framestart:frame), YY(framestart:frame,3), 'color', [1 0 1], 'linewidth', 2);
        set(h5, 'xlim', [tstart tstart+timewindow], 'box', 'on');
        ylabel(h5, 'x_3 (m)');
        xlabel(h5, 't (s)');
        grid(h5, 'on');
      
        drawnow;
    end
end

end

