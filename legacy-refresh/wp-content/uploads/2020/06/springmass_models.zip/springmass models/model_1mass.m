%% the simulatin is wrapped in function model_1mass()
function []= model_1mass()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% model_1mass.m                        
% author:	Xiaoxiang Yu 	
% date:     Octoboer, 2012  
% revised:  March 21, 2014
%
% This file is to simulate an actuated 1D spring-mass model consisting
% of one mass are one linear spring. A sinusoidal force applies on the
% mass. There are two state variables in total, which are the position
% and velocity of each mass. 
% ode45 is applied for numerical computation.
%
% references: 
% [1] Yu, X. et al. (2014). Minimalistic models of an energy efficient vertical hopping robot, IEEE Transactions on Industrial Electronics, 61(2): 1053-1062.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% parameter description %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% amplitude A(N), frequency omega(rad/s) and offset phi(rad) of force F,
% F = A*cos(omega*t+phi)
A = 2;
omega = 20;
phi = 0;

% mass m(kg)
m = .5;

% spring stiffness constant k(N/m), damping c(Ns/m) and natural length L0(m)
k = 200;
c = .1;
L0 = .5;

% initial conditions: mass position y(m) and mass velocity y_dot(m/s)
y = L0;
y_dot = 0;

% initial phase: 1 flight; 2 stance support, wrong phase will likely get a
% irregular behavior.
initialphase = 2;

%number of cycles of stumilation
ncycles =  20;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% don't modify the following codes

g = 9.81;
errorthreshold = 10^-4;
t_end=0;
TT = 0;
YY = y;
%% simulate ncycles steps
for j = 1:ncycles*2
    switch initialphase
        % flight phase
        case 1
            options=odeset('events',@events_flight, 'RelTol', errorthreshold);
            [T, Y] = ode45(@diff_func, [0 2], [y y_dot], options);
            
        % stance phase
        case 2
            options=odeset('events',@events_stance, 'RelTol', errorthreshold);
            [T, Y] = ode45(@diff_func, [0 2], [y y_dot], options);
    end
    
    if ~isreal(Y) || (max(Y(:)) > L0*10) || (min(Y(1:end/2)) < -errorthreshold)
        disp('Values are out of reasonable range.');
        break;
    end
    
    % store data
    TT = [TT; t_end+T];
    YY = [YY; Y(:,1)];

    % update variable
    t_end = t_end+T(end);
    y = Y(end,1);
    y_dot = Y(end,2);
    
    % switching between phases
    initialphase = 3 - initialphase;
end
display(['Simulation stops at time ', num2str(t_end), 's.']);

% play animation
playanimation(TT, YY);

%% EoM definition
function [value,isterminal,direction] = events_flight(~,y)
    if isreal(y(1))
        value = y(1) - L0;
    else
        value = -1;
    end
    isterminal=1;
    direction = -1;
end

function [value,isterminal,direction] = events_stance(~,y)
    if isreal(y(1))
        value = L0 - y(1);
    else
        value = -1;
    end
    isterminal=1;
    direction = -1;
end
% differential equeations
function dy = diff_func(t,y)
    f = A*cos(omega*(t_end+t)+phi);
    
    dy = zeros(2,1);
    dy(1) = y(2);
    if initialphase == 1 
        dy(2) = -g+f/m;
    end
    if initialphase == 2
        dy(2) = -(y(1)-L0)*k/m-g+f/m-c/m*y(2);
    end
    
end

%% visualization
function playanimation(TT, YY)
    
    figure;
    h2 = subplot(2,2,2);
    h3 = subplot(2,2,4);
    h1 = subplot(2,2,[1 3]);
    
    if omega ~= 0
        timewindow = 8*pi/omega;
    else
        timewindow = 5;
    end
    timestep = timewindow/100;
    
    F = A*cos(omega*TT+phi);
    Y1limit = [-max(YY(:,1))*.1 max(YY(:,1))*1.2];
    
    framestart = 1;
    tstart = 0;
    frame = 1;
    for i = 1:TT(end)/timestep
        while timestep * i > TT(frame)
            frame = frame + 1;
        end
        if TT(frame) >= tstart + timewindow;
            framestart = frame;
            tstart = tstart + timewindow;
        end

        hold(h1, 'off');
        plot(h1, [0, 0], [YY(frame) max(0,YY(frame)-L0)], 'g', 'linewidth', 3);
        hold(h1, 'on');
        plot(h1, [0, 0], [YY(frame) YY(frame)], 'o', 'markersize', 10, 'markerfacecolor', [1 0 0], 'markeredgecolor', [0 0 0]);
        plot(h1, [-4 4], [0 0], 'k--', 'linewidth',2);
        text(-3.5,1.1*max(YY),[num2str(TT(frame),'%.2f'),'s'], 'fontsize', 15);
        if F(frame) >= 0
            arrow = '\uparrow';
        else
            arrow = '\downarrow';
        end
        if F(frame) ~= 0
            text(.5,YY(frame),[arrow, 'f'],'fontsize',ceil(30*abs(F(frame))/max(abs(F))));
        end
        ylabel(h1, 'height (m)');
        set(h1, 'xlim', [-4 4], 'ylim', Y1limit, 'xtick', []);
      
        plot(h2, TT(framestart:frame), F(framestart:frame), 'k', 'linewidth', 2);
        set(h2, 'xlim', [tstart tstart+timewindow], 'box', 'on', 'xtick', []);
        ylabel(h2, 'f (N)');
        grid(h2, 'on');

        plot(h3, TT(framestart:frame), YY(framestart:frame), 'r', 'linewidth', 2);
        set(h3, 'xlim', [tstart tstart+timewindow], 'box', 'on');
        ylabel(h3, 'x (m)');
        xlabel(h3, 't (s)');
        grid(h3, 'on');
      
        drawnow;
    end
end

end

