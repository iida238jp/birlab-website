Please read this file before implementing simulations under this folder.
This approach consists of 4 files:
1. model_1mass.m
2. model_2mass.m
3. model_3mass.m
4. readme.txt

The first three files aim to simulate three actuated 1D spring-mass models in the Matlab environment,
which include one, two and three models, respectively. At the beginning of each file, there is an
introduction to this simulation and description of the parameters used in this simulation. Set 
desired parameters and simply run through each file in Matlab to simulate the corresponding model.

video:
http://www.birl.ethz.ch/Robots/mp4/3MassModel_xiaoxiang.mp4

references: 
[1] Yu, X. et al. (2014). Minimalistic models of an energy efficient vertical hopping robot, IEEE Transactions on Industrial Electronics, 61(2): 1053-1062.